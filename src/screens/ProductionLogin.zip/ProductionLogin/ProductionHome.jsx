import { useFocusEffect, useNavigation } from "@react-navigation/native";
import React, { useCallback } from "react";
import { StatusBar, StyleSheet, View, TouchableOpacity, Image,Text, FlatList } from "react-native";
import { colors, fonts } from "../../config/theme";
import Feather from 'react-native-vector-icons/Feather';


const ProductionHome = () => {
    const navigation = useNavigation();

    useFocusEffect(
        useCallback(() => {
            StatusBar.setBackgroundColor(colors.commoncolor);
            StatusBar.setBarStyle("dark-content");
        })
    )

    const ProductionData=[
        {id:'1',name:'Naresh',inchange:'Incharge',BTH:'BTH-2025-001',date:'11/9/2025'},
        {id:'2',name:'Ramesh',inchange:'Incharge',BTH:'BTH-2025-002',date:'12/9/2025'},
        {id:'3',name:'Rajesh',inchange:'Incharge',BTH:'BTH-2025-003',date:'17/9/2025'},
        {id:'4',name:'RamKrishana',inchange:'Incharge',BTH:'BTH-2025-004',date:'19/9/2025'},
        {id:'5',name:'suresh',inchange:'Incharge',BTH:'BTH-2025-005',date:'21/9/2025'},
    ]
    return (

        <View style={styles.container}>

            <View style={styles.header}>
                {/* <StatusBar translucent backgroundColor="#EF3D3B" barStyle="light-content" /> */}
                <View style={styles.start_header}>
                    <TouchableOpacity style={styles.for_flex} onPress={()=>navigation.goBack()}>
                        <Feather name="arrow-left" size={24} color="#fff" style={styles.arrow} />
                        <Image source={require('../../assets/signin_logo.png')} style={styles.img_header} />
                    </TouchableOpacity>
                    
                    <TouchableOpacity onPress={() => navigation.navigate("TelecallerProfile")}>
                        <Feather name="user" size={24} color="#fff" style={styles.icon} />
                    </TouchableOpacity>
                </View>
            </View>

            <View style={styles.body}>

                <View style={styles.start_header}>
                    <Text style={styles.title}>Production</Text>
                    <TouchableOpacity style={styles.btn} onPress={()=>navigation.navigate("AddProduction")}>
                        <Feather name="plus" size={14} color="#fff" />
                        <Text style={styles.btn_text}>Add Production</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.buttom}>
                    <FlatList
                    data={ProductionData}
                    keyExtractor={item=>item.id}
                    contentContainerStyle={{paddingHorizontal:2,paddingBottom:150}}
                    showsVerticalScrollIndicator={false}
                    renderItem={({item})=>{
                        return(
                            <View style={styles.card}>
                                <View style={styles.start_header}>
                                    <Text style={styles.title}>{item.name}<Text style={styles.inchange}>({item.inchange})</Text></Text>
                                    <Text style={styles.date}>{item.date}</Text>
                                </View>
                                <View style={[styles.start_header,{paddingTop:5}]}>
                                    <Text style={styles.BTH}>{item.BTH}</Text>
                                    <TouchableOpacity onPress={()=>navigation.navigate("EditProduction")}>
                                        <Feather name="edit" size={18} color="#EF3D3B"/>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        )
                    }}
                    />
                </View>
            </View>

        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
    },
    body:{
        flex:1,
        backgroundColor:colors.white,
        paddingHorizontal:12,
        flexDirection:'column',
        gap:15,
        marginTop:20,
    },
    header: {
        backgroundColor: colors.commoncolor,
        height: 130,
        paddingTop: 60,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
        paddingHorizontal: 15,
        shadowColor: colors.black,
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 10,
    },
    inchange:{
        fontSize:12,
        fontWeight:400,
        fontFamily:fonts.sfregular,
        color:colors.inputfieldcolor,
    },
    BTH:{
        fontSize:15,
        fontWeight:500,
        fontFamily:fonts.sfmedium,
        color:colors.simpleblack,
    },
    start_header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',

    }, icon: {
        backgroundColor: colors.hrhomeprofile,
        padding: 9,
        borderRadius: 22,
    },
    img_header: {
        height: 39,
        width: 168,
        resizeMode: 'contain',
    },
    title: {
        fontSize: 18,
        fontWeight: 700,
        fontFamily: fonts.sfbold,
        color: colors.black,
    },
    btn: {
        backgroundColor: colors.commoncolor,
        borderRadius: 8,
        paddingTop: 16,
        paddingBottom: 16,
        paddingLeft: 25,
        paddingRight: 25,
        flexDirection: 'row',
        alignItems: 'center',
        // marginBottom: 15,
    },
    btn_text: {
        paddingLeft: 5,
        fontSize: 14,
        fontWeight: 700,
        fontFamily: fonts.sfbold,
        color: colors.white
    },
    card:{
        backgroundColor:colors.white,
        borderRadius: 10,
        shadowColor: colors.black,
        shadowOpacity: 0.1,
        padding: 12,
        shadowRadius: 6,
        elevation: 4,
        marginBottom: 5,
        marginTop: 10,
    },
    for_flex:{
        flexDirection:'row',
        alignItems:'center',
    },
})
export default ProductionHome